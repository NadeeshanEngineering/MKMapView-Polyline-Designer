//
//  AppDelegate.h
//  SampleMapViewManager
//
//  Created by Nadeeshan Jayawardana on 9/4/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

