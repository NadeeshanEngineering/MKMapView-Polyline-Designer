//
//  ViewController.m
//  SampleMapViewManager
//
//  Created by Nadeeshan Jayawardana on 9/4/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    mapPolylineDesigner = [[MapPolylineDesigner alloc] initWithMapView:_mapView Type:MKMapTypeStandard andViewController:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)refreshMapButtonAction:(id)sender {
    [mapPolylineDesigner initMapView];
}

- (IBAction)pickupLocationButtonAction:(id)sender {
    [mapPolylineDesigner setPickupLocationWithCoordinateOfLongitude:_mapView.centerCoordinate.longitude andLatitude:_mapView.centerCoordinate.latitude];
}

- (IBAction)dropoffLocationButtonAction:(id)sender {
    [mapPolylineDesigner setDropoffLocationWithCoordinateOfLongitude:_mapView.centerCoordinate.longitude andLatitude:_mapView.centerCoordinate.latitude];
}

// Design Polyline On Mapview
- (MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay{
    if ([overlay isKindOfClass:[MKPolyline class]]) {
        MKPolylineRenderer *renderer = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
        [renderer setStrokeColor:[UIColor blueColor]];
        [renderer setLineWidth:8.0];
        return renderer;
    }
    return nil;
}

// Return Polyline Data
- (void)getPolylineDataOfMapView:(NSDictionary *)polylineDataSource {
    NSLog(@"More info: %@",polylineDataSource);
    _pickupLocationLabel.text = [NSString stringWithFormat:@"%@",[[[[[polylineDataSource valueForKey:@"source"] valueForKey:@"legs"] valueForKey:@"start_address"] objectAtIndex:0] objectAtIndex:0]];
    _dropoffLocationLabel.text = [NSString stringWithFormat:@"%@",[[[[[polylineDataSource valueForKey:@"source"] valueForKey:@"legs"] valueForKey:@"end_address"] objectAtIndex:0] objectAtIndex:0]];
    _distanceLabel.text = [NSString stringWithFormat:@"%@",[[[[[[polylineDataSource valueForKey:@"source"] valueForKey:@"legs"] valueForKey:@"distance"] objectAtIndex:0] objectAtIndex:0] valueForKey:@"text"]];
    _durationLabel.text = [NSString stringWithFormat:@"%@",[[[[[[polylineDataSource valueForKey:@"source"] valueForKey:@"legs"] valueForKey:@"duration"] objectAtIndex:0] objectAtIndex:0] valueForKey:@"text"]];
}

@end
