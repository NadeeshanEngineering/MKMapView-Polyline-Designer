//
//  ViewController.h
//  SampleMapViewManager
//
//  Created by Nadeeshan Jayawardana on 9/4/17.
//  Copyright © 2017 Nadeeshan Jayawardana (NEngineering). All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "MapPolylineDesigner.h"

@interface ViewController : UIViewController {
    MapPolylineDesigner *mapPolylineDesigner;
}

@property (strong, nonatomic) IBOutlet UILabel *pickupLocationLabel;
@property (strong, nonatomic) IBOutlet UILabel *dropoffLocationLabel;
@property (strong, nonatomic) IBOutlet UILabel *distanceLabel;
@property (strong, nonatomic) IBOutlet UILabel *durationLabel;

@property (strong, nonatomic) IBOutlet MKMapView *mapView;

- (IBAction)pickupLocationButtonAction:(id)sender;
- (IBAction)dropoffLocationButtonAction:(id)sender;
- (IBAction)refreshMapButtonAction:(id)sender;

@end

